package com.lfit.ms_security.Services;

import com.lfit.ms_security.Models.*;
import com.lfit.ms_security.Repositories.PermissionRepository;
import com.lfit.ms_security.Repositories.RolePermissionRepository;
import com.lfit.ms_security.Repositories.UserRepository;
import com.lfit.ms_security.Repositories.UserRoleRepository;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ValidatorsService {
    @Autowired
    private JwtService jwtService;

    @Autowired
    private PermissionRepository thePermissionRepository;
    @Autowired
    private UserRepository theUserRepository;
    @Autowired
    private RolePermissionRepository theRolePermissionRepository;

    @Autowired
    private UserRoleRepository theUserRoleRepository;

    private static final String BEARER_PREFIX = "Bearer ";

    public boolean validationRolePermission(HttpServletRequest request,
                                            String url,
                                            String method) {
        User theUser = this.getUser(request);
        if (theUser == null) return false;

        List<UserRole> roles = this.theUserRoleRepository.getRolesByUser(theUser.getId());
        System.out.println("Antes URL " + url + " metodo " + method);
        url = url.replaceAll("[0-9a-fA-F]{24}|\\d+", "?");
        System.out.println("URL " + url + " metodo " + method);

        Permission thePermission = this.thePermissionRepository.getPermission(url, method);

        // ✅ Sale inmediatamente al encontrar el permiso
        for (UserRole actual : roles) {
            Role theRole = actual.getRole();
            if (theRole != null && thePermission != null) {
                System.out.println("Rol " + theRole.getId() + " Permission " + thePermission.getId());
                Optional<RolePermission> theRolePermission = this.theRolePermissionRepository
                        .getRolePermission(theRole.getId(), thePermission.getId());
                if (theRolePermission.isPresent()) {
                    return true; // ✅ Corta el loop inmediatamente
                }
            }

        }
        return false;
    }

    /***
     * Analiza el token y descifra los datos para rearmar el usuario
     * @param request que contiene el token
     * @return el usuario de base datos que tiene el id presente en el token
     */
    public User getUser(final HttpServletRequest request) {
        User theUser = null;
        String authorizationHeader = request.getHeader("Authorization");
        System.out.println("Header " + authorizationHeader);
        if (authorizationHeader != null && authorizationHeader.startsWith(BEARER_PREFIX)) {
            String token = authorizationHeader.substring(BEARER_PREFIX.length());
            System.out.println("Bearer Token: " + token);
            User theUserFromToken = jwtService.getUserFromToken(token);
            if (theUserFromToken != null) {
                theUser = this.theUserRepository.findById(theUserFromToken.getId())
                        .orElse(null);
            }
        }
        return theUser;
    }
}
